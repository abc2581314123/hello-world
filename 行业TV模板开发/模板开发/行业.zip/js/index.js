var domC = document.querySelectorAll('.move');



pageControls = {
    ele: domC[0],
    index: 0,
    moveDir: '',
    leaved: function(){
    },
    entered: function(){
    }
}

setTimeout(function(){
    bytueTools.fnAddEleClass(pageControls.ele, 'focus');
},100)
