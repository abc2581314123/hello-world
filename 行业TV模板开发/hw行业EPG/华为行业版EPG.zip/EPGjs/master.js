function keyUp(){
	pageControl.moveUp();
}
function keyRight(){
	pageControl.moveRight();
}
function keyDown(){
	pageControl.moveDown();
}
function keyLeft(){
	pageControl.moveLeft();
}
function keyOk(){
	pageControl.ok();
}
function keyBack(){
	
}